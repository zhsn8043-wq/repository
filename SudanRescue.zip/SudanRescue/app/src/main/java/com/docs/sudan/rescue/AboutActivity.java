package com.sudan.rescue;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        
        TextView developerText = findViewById(R.id.developer_text);
        TextView ideaText = findViewById(R.id.idea_text);
        TextView messageText = findViewById(R.id.message_text);
        
        String developerName = getString(R.string.developer_name);
        String ideaOwner = getString(R.string.developer_name); // نفس الشخص
        
        developerText.setText(String.format(getString(R.string.developed_by), developerName));
        ideaText.setText(String.format(getString(R.string.project_idea), ideaOwner));
        messageText.setText(R.string.developer_message);
    }
}