package com.sudan.rescue;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

public class AirAlert implements SensorEventListener {

    private static final String TAG = "AirAlert";
    private Context context;
    private WifiManager wifiManager;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private AlertListener listener;

    private Handler alertHandler = new Handler();
    private Runnable scanRunnable;

    private long lastVibrationTime = 0;
    private static final long VIBRATION_COOLDOWN = 10000; // 10 ثواني بين الإنذارات
    private static final float VIBRATION_THRESHOLD = 20.0f; // حساسية الاهتزاز

    public AirAlert(Context context) {
        this.context = context;
        this.wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        this.sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);

        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
    }

    public void startMonitoring(AlertListener listener) {
        this.listener = listener;

        // 1. بدء مراقبة شبكات Wi-Fi
        scanForAircraftWiFi();

        // 2. بدء مراقبة الاهتزازات (للكشف عن الطائرات القريبة)
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }

        // 3. تسجيل مستقبل لنتائج فحص Wi-Fi
        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        context.registerReceiver(wifiScanReceiver, filter);

        Log.d(TAG, "AirAlert monitoring started");
    }

    public void stopMonitoring() {
        alertHandler.removeCallbacks(scanRunnable);
        sensorManager.unregisterListener(this);
        try {
            context.unregisterReceiver(wifiScanReceiver);
        } catch (IllegalArgumentException e) {
            // المتلقي غير مسجل
        }
        Log.d(TAG, "AirAlert monitoring stopped");
    }

    private void scanForAircraftWiFi() {
        scanRunnable = new Runnable() {
            @Override
            public void run() {
                if (wifiManager != null) {
                    wifiManager.startScan();
                }
                // أعد الفحص كل 30 ثانية
                alertHandler.postDelayed(this, 30000);
            }
        };
        alertHandler.post(scanRunnable);
    }

    private final BroadcastReceiver wifiScanReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null &&
                    intent.getAction().equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {

                List<ScanResult> results = wifiManager.getScanResults();
                checkForThreats(results);
            }
        }
    };

    private void checkForThreats(List<ScanResult> results) {
        if (results == null || results.isEmpty()) return;

        for (ScanResult result : results) {
            String ssid = result.SSID;
            if (ssid == null || ssid.isEmpty()) continue;

            // أنماط أسماء شبكات قد تكون مرتبطة بطائرات بدون طيار أو عسكرية
            String lowerSSID = ssid.toLowerCase();
            if (lowerSSID.contains("drone") ||
                    lowerSSID.contains("uav") ||
                    lowerSSID.contains("aircraft") ||
                    lowerSSID.contains("air") ||
                    lowerSSID.contains("sky") ||
                    lowerSSID.contains("fly") ||
                    lowerSSID.contains("mavic") ||
                    lowerSSID.contains("phantom") ||
                    lowerSSID.contains("inspire")) {

                int signalStrength = result.level;
                String threatMessage = "⚠️ شبكة مشبوهة: " + ssid + " (قوة الإشارة: " + signalStrength + " dBm)";

                if (listener != null) {
                    listener.onPotentialThreatDetected(threatMessage);
                }
                break;
            }
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            // حساب مقدار الاهتزاز الكلي
            double acceleration = Math.sqrt(x * x + y * y + z * z);
            // قيمة الجاذبية الأرضية حوالي 9.8، أي زيادة كبيرة تعني اهتزاز قوي
            if (acceleration > VIBRATION_THRESHOLD) {
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastVibrationTime > VIBRATION_COOLDOWN) {
                    lastVibrationTime = currentTime;

                    String message = "🚨 اهتزاز قوي غير طبيعي! " +
                            "احتمال وجود طيران قريب.";

                    if (listener != null) {
                        listener.onPotentialThreatDetected(message);
                    }
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // لا نحتاج هذه
    }

    public interface AlertListener {
        void onPotentialThreatDetected(String message);
    }
}